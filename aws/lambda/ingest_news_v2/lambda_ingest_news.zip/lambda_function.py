
import os
import json
import hashlib
import requests
from datetime import datetime, timezone
import boto3
from bs4 import BeautifulSoup

# ========== Config ==========
BUCKET = os.environ.get("BUCKET", "")
TABLE_DOCS = os.environ.get("TABLE_DOCS", "news_documents")
TABLE_STOCK = os.environ.get("TABLE_STOCK", "stock_prices")
TABLE_OPTION = os.environ.get("TABLE_OPTION", "stock_options")
SOURCE = "polygon"
API_KEY = os.environ.get("POLYGON_API_KEY")

ALLOWED_TICKERS = {"RBLX", "AAPL", "NVDA", "TSLA", "AMZN"}

NEWS_URL = "https://api.polygon.io/v2/reference/news"
PRICE_URL = "https://api.polygon.io/v1/open-close/{ticker}/{date}"
OPTION_URL = "https://api.polygon.io/v3/snapshot/options/{ticker}"

s3 = boto3.client("s3")
ddb_docs = boto3.resource("dynamodb").Table(TABLE_DOCS)
ddb_price = boto3.resource("dynamodb").Table(TABLE_STOCK)
ddb_option = boto3.resource("dynamodb").Table(TABLE_OPTION)

# ========== Utilities ==========
def now_iso():
    return datetime.now(timezone.utc).isoformat()

def sha256_hex(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def news_exists(doc_id):
    try:
        resp = ddb_docs.get_item(Key={"doc_id": doc_id})
        return "Item" in resp
    except Exception as e:
        print("[Error] Failed checking news existence:", str(e))
        return False

def fetch_news(ticker, limit=50):
    params = {
        "ticker": ticker,
        "order": "desc",
        "limit": limit,
        "apiKey": API_KEY,
    }
    resp = requests.get(NEWS_URL, params=params)
    return resp.json().get("results", [])

def fetch_price(ticker, date):
    url = PRICE_URL.format(ticker=ticker, date=date)
    resp = requests.get(url, params={"apiKey": API_KEY})
    data = resp.json()
    if "close" in data:
        ddb_price.put_item(Item={
            "ticker": ticker,
            "date": date,
            "price": data["close"],
            "fetched_at": now_iso()
        })

def fetch_option(ticker):
    url = OPTION_URL.format(ticker=ticker)
    resp = requests.get(url, params={"apiKey": API_KEY})
    data = resp.json()
    ddb_option.put_item(Item={
        "ticker": ticker,
        "data": json.dumps(data),
        "fetched_at": now_iso()
    })

def scrape_body(article_url):
    try:
        resp = requests.get(article_url, timeout=10)
        soup = BeautifulSoup(resp.text, "html.parser")
        paras = soup.find_all("p")
        return "\n".join([p.get_text() for p in paras if p.get_text().strip()])
    except Exception as e:
        print("[Error] Failed to scrape body:", str(e))
        return ""

# ========== Main Handler ==========
def lambda_handler(event, context):
    for ticker in ALLOWED_TICKERS:
        results = fetch_news(ticker)
        for item in results:
            doc_id = item.get("id")
            if not doc_id or news_exists(doc_id):
                continue

            article_url = item.get("article_url", "")
            body = scrape_body(article_url)
            if not body:
                print("[SKIP] No body for", doc_id)
                continue

            s3_key = f"polygon/{doc_id}.txt"
            s3.put_object(Bucket=BUCKET, Key=s3_key, Body=body.encode("utf-8"))

            ddb_docs.put_item(Item={
                "doc_id": doc_id,
                "source": SOURCE,
                "ticker": ticker,
                "title": item.get("title", ""),
                "summary": item.get("description", ""),
                "published_utc": item.get("published_utc", ""),
                "url": article_url,
                "s3_key": s3_key,
                "fetched_at": now_iso(),
            })

            date = item.get("published_utc", "")[:10]
            if date:
                fetch_price(ticker, date)
            fetch_option(ticker)

    return {"status": "ok"}
